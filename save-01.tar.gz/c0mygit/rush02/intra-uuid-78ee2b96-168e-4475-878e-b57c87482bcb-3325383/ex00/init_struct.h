/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_struc.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/27 11:50:54 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/27 18:29:52 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INIT_STRUCT_H
# define INIT_STRUCT_H

# include "struct_dict.h"

t_dict	*init_struct_tab(int size, int size2);

#endif
