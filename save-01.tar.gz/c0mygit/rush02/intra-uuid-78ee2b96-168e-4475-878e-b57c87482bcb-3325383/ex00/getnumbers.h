/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   getnumbers.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/27 12:01:52 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/27 12:52:50 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GETNUMBERS_H
# define GETNUMBERS_H

int	ft_zero(char *str);
int	*ft_getnumbers(char *str);

#endif
