/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fill_tab.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/27 11:53:57 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/27 12:54:13 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INIT_NUMBERS_H
# define INIT_NUMBERS_H

int ft_malloc_sizeoftab(char *str);
int *ft_init_tab(char *str);

#endif
