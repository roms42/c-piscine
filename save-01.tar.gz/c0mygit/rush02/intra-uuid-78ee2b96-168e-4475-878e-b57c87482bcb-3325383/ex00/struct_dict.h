/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct_dict.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/26 16:46:14 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/27 20:25:40 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRUCT_DICT_H
# define STRUCT_DICT_H

typedef struct	s_dict
{
	char *nb;
	char *lettres;
}				t_dict;

#endif
