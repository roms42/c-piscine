/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/12 19:18:25 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/12 22:50:38 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_str_is_lowercase(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		if (str[i] <= 'a' || str[i] >= 'z')
		{
			return (0);
		}
		i++;
	}
	return (1);
}

int	main()
{
	char dest[] = "jdoieKDls";
	printf("%d", ft_str_is_lowercase(dest));
}
