/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/12 19:22:20 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/12 22:55:03 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_str_is_uppercase(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		if (str[i] <= 'A' || str[i] >= 'Z')
		{
			return (0);
		}
		i++;
	}
	return (1);
}

int	main()
{
	char dest[] = "PDJEO4";
	printf("%d", ft_str_is_uppercase(dest));
}
