/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/12 23:48:24 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/13 10:22:01 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_numeric(char c)
{
	if (c >= '0' && c <= '9')
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int ft_alpha(char c)
{
	if ((c >= 'A' && c <= 'Z') || (c >= 'a' || c <= 'z'))
	{
		return (1);
	}
	else
	{
		return (0);
	}
}


int	ft_strnumeric(char *str)
{
	int i;
	
	i = 0;
	while (str[i])
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			return (1);
		}
		i++;
	}
	return (0);
}

int ft_stralpha(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		if ((str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= 'a' || str[i] <= 'z'))
		{
			return (1);
		}
		i++;
	}
	return (0);
}

int	ft_mot(char *str)
{
	int j;

	j = 0;
	while (ft_strnumeric(str) == 1 || ft_stralpha(str) == 1)
	{
		j++;
	}
	return (j);
}

char	*ft_strcapitalize(char *str)
{
	int i;
	int j;

	i = 0;
	while (str[i]);
	{
		if (ft_strnumeric(str) == 0 || ft_stralpha == 0)
		{
			ft_mot(str);
			if (ft_alpha[i-j] == 1)
			str[i-j] -= 32;
		}
	}
}

int main()
{
	char dest[] = "Salut";
	printf("%c", *ft_strcapitalize(*dest));
}
