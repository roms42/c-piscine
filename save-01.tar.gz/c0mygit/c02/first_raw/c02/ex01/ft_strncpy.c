/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rberthau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/11 14:05:01 by rberthau          #+#    #+#             */
/*   Updated: 2020/09/12 21:26:11 by rberthau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int i;

	i = 0;
	while (src[i] && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (src[i] != 0)
	{
		dest[i] = '\0';
		i++;
	}
	dest[i] = src[i];
	return (dest);
}

int	main()
{
	char dest[] = "Salut";
	char src[] = "Hello";
	printf("%s --" "%s \n", dest, src);
	ft_strncpy(dest, src, 3);
	printf("%s --" "%s", dest, src);
}
