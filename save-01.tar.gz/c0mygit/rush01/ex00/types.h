/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   types.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dchheang <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/19 20:08:09 by dchheang          #+#    #+#             */
/*   Updated: 2020/09/20 22:10:29 by dchheang         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef types_h
#define types_h

typedef struct view{
	int value;
	int max;
} View;

typedef struct board
{
	int ncolumn;
	int nrow;
	int **square;
	View **colview;
	View **rowview;
} Board;

int backtrack(int c, int l, Board b, int nb);
Board init_board(int ncolumn, int nrow);
Board boardcopy(Board dest);
void print_result(Board b);
void fill_rc_table(char *str, Board b);
void ft_putchar(char c);
void ft_strlen(char *str);
void ft_putstr(char *str);
int check_string(char *str);
int check_same_number(int c, int l, Board b, int nb);
Board add_view(int c, int l, Board b);
int check_view(int c, int l, Board b);

#endif
